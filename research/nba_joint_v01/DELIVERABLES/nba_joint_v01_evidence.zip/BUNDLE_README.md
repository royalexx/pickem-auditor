# NBA WS5 evidence and implementation

Read NBA_WS5_Implementation_Report.md. Final scenarios, distributions, scores, source bytes, manifests and source/test code are included. Full intermediate runs remain in the draft PR. Exact full historical reproduction requires a complete Git checkout with the pinned warehouse commit; follow research/nba_joint_v01/README.md. This bundle is an evidence handoff, not a replacement for Git history. All results remain research-only.
