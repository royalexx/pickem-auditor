#!/usr/bin/env python3
"""One immutable per-pick view of production consensus and comparison models.

All displayed probabilities refer to the original player's exact side/line and
are conditional on no push. Raw masses, versions, timestamps and missing reasons
are retained in JSON. Missing NUTS fits are never replaced with another model.
"""
from __future__ import annotations
import argparse
import csv
from datetime import datetime, timezone
import hashlib
import json
import math
import os
from pathlib import Path
import statistics

from odds_providers import approved_book_name, normalize_player, normalize_team
from prediction_scoring import conditional_win
from probability_blend import production_policy
from historical_ensemble import calculate as calculate_historical_ensemble
from nuts_slate_shadow import instant, identity

VERSION='slate-model-comparison-v1'
FOLDERS={'Bayesian_A':'bayesian_shadow','Bayesian_B':'bayesian_b_shadow',
         'NUTS_saves':'nhl_joint_saves_shadow','NUTS_targets':'nfl_context',
         'NUTS_population':'population_nuts_shadow',
         'NUTS_provisional':'provisional_nuts_shadow'}
COLUMNS=('sport','player','stat','side','line','Engine_A','Engine_B','Consensus',
         'Bayesian_A','Bayesian_B','Market','NUTS','NUTS_provisional','NUTS_model','NUTS_status',
         'Consensus_gap_pp','production_consensus_available','original_rank','block_reason')


def rows(path):
    p=Path(path)
    return [json.loads(s) for s in p.read_text().splitlines() if s.strip()] if p.is_file() else []


def probability(win,push):
    if type(win) not in (int,float) or type(push) not in (int,float):return None
    try:return conditional_win(win,push)
    except ValueError:return None


def masses(item,*,win='q_win',push='q_push'):
    p=probability(item.get(win),item.get(push))
    return {'probability':p,'q_win':item.get(win) if p is not None else None,'q_push':item.get(push) if p is not None else None,
            'version':item.get('model_build') or item.get('version'),
            'numerical_revision':item.get('numerical_revision'),
            'status':'forecast' if p is not None else 'unavailable',
            'reason':None if p is not None else item.get('reason') or 'probability_not_recorded',
            'reliable':item.get('reliable'),'generated_at':item.get('generated_at')}


def source_market(row,quotes):
    try:at,start=instant(row['forecast_at']),instant(row['event_start'])
    except (ValueError,TypeError,KeyError):
        return {'probability':None,'status':'unavailable','reason':'market_event_time_unverified'}
    selections={}
    attached={approved_book_name(b.get('book')):b for b in (row.get('books') or []) if isinstance(b,dict)}
    for q in quotes:
        book=approved_book_name(q.get('book'));b=attached.get(book)
        if not book or not b:continue
        if (q.get('sport')!=row.get('sport') or q.get('stat')!=row.get('stat')
                or normalize_player(q.get('player'))!=normalize_player(row.get('player'))
                or normalize_team(q.get('team'))!=normalize_team(row.get('team'))
                or normalize_team(q.get('opponent'))!=normalize_team(row.get('opponent'))
                or q.get('line')!=row.get('reference_line') or b.get('line')!=row.get('reference_line')
                or q.get('over_odds')!=b.get('over') or q.get('under_odds')!=b.get('under')):continue
        try:
            updated=instant(q.get('retrieved_at'))
            if instant(q.get('event_start'))!=start or not updated<=at<start:continue
            for k in ('event_id','event_id_namespace'):
                if row.get(k) and str(row[k])!=str(q.get(k)):raise ValueError('event_mismatch')
            odds=[q.get('over_odds'),q.get('under_odds')]
            if any(type(x) not in (int,float) or not math.isfinite(x) or abs(x)<100 for x in odds):continue
            over,under=[-x/(-x+100) if x<0 else 100/(x+100) for x in odds]
            value=over/(over+under) if row['side']=='over' else under/(over+under)
            key=(str(q.get('event_id')),str(q.get('event_id_namespace')))
            prior=selections.get(book)
            if prior is None or updated>prior[0]:selections[book]=(updated,value,key)
        except (ValueError,TypeError):continue
    # Never silently combine different events when the original ID is missing.
    event_ids={v[2] for v in selections.values()}
    if len(event_ids)>1 or not selections:
        return {'probability':None,'status':'unavailable','reason':'no_unambiguous_frozen_paired_prices'}
    return {'probability':statistics.median(v[1] for v in selections.values()),'status':'forecast',
            'version':'normalized-paired-American-odds-median-v1','conditional_on_nonpush':True,
            'books':sorted(selections),'observed_at':max(v[0] for v in selections.values()).isoformat()}


def index_sidecars(items):
    result={}
    for item in items:
        key=identity(item)
        if key in result and result[key]!=item:raise ValueError('conflicting_model_sidecar_identity')
        result[key]=item
    return result


def linked_probability(row,item,*,nfl_targets=False):
    if not item:return {'probability':None,'status':'unavailable','reason':'model_output_not_recorded'}
    if item.get('status')!='forecast':
        return {'probability':None,'status':'unavailable','reason':item.get('reason') or 'model_unavailable',
                'version':item.get('version'),'model_id':item.get('model_id')}
    result=masses(item)
    try:
        generated=instant(item.get('generated_at') or (item.get('forecast_at') if nfl_targets else None))
        if not instant(row['forecast_at'])<=generated<instant(row['event_start']):
            raise ValueError('model_not_completed_before_event')
    except (ValueError,TypeError):
        result.update(probability=None,status='unavailable',reason='model_completion_time_unverified_or_poststart')
    result['model_id']=item.get('model_id') or item.get('release_tag') or item.get('model_source_digest')
    result['trained_through']=item.get('trained_through')
    result['training_source_digest']=item.get('training_source_digest') or item.get('model_source_digest')
    result['sampler_diagnostics']=item.get('sampler_diagnostics')
    if item.get('provisional') is True:
        result.update(provisional=True,ranking_allowed=False,publication_eligible=False,
                      model_run_id=item.get('model_run_id'),
                      strict_convergence_passed=False)
    return result


def build(row,indices,quotes,policy=None):
    key=identity(row);a=row.get('engine_a') or {};b=row.get('engine_b') or {};blend=row.get('blend') or {}
    models={'Engine_A':masses(a,win='q_win_robust',push='q_push_robust'),
            'Engine_B':masses(b)}
    models['Consensus']=masses({'q_win':row.get('q_model'),'q_push':row.get('q_push'),
                               'version':blend.get('version')})
    if not (blend.get('production_policy') and blend.get('available')):
        models['Consensus'].update(probability=None,status='unavailable',
                                   reason='production_consensus_not_available')
    for name in ('Bayesian_A','Bayesian_B'):
        models[name]=linked_probability(row,indices.get(name,{}).get(key))
    models['Market']=source_market(row,quotes)
    nuts={}
    for name in ('NUTS_saves','NUTS_population'):
        item=indices.get(name,{}).get(key)
        if item:nuts[name]=linked_probability(row,item)
    target=indices.get('NUTS_targets',{}).get(key)
    if target:nuts['NUTS_targets']=linked_probability(row,target,nfl_targets=True)
    # Fixed family priority; never select a model based on its probability.
    selected=next((k for k in ('NUTS_targets','NUTS_saves','NUTS_population')
                   if nuts.get(k,{}).get('status')=='forecast'),None)
    chosen=nuts[selected] if selected else {'probability':None,'status':'unavailable',
                    'reason':next((x.get('reason') for x in nuts.values() if x.get('reason')),
                                  'no_verified_trained_model_for_this_pick')}
    models['NUTS']=chosen
    historical_ensemble = None
    if policy and policy.get('model') == 'historical_consensus_engine_b':
        # Only same-contract, pre-event sidecars can enter the final historical
        # production pool. The earlier parent A/B preview is never promoted.
        if (a.get('reliable') is True and a.get('observation_ids_verified') is True
                and b.get('reliable') is True and not b.get('abstain')
                and b.get('baseline_origin') == 'collector_observations'):
            historical_ensemble=calculate_historical_ensemble(
                models, weight_historical=policy['weight_a'],
                weight_b=policy['weight_b'],
                required=tuple(policy['historical_required']),
                min_historical=policy['historical_min_coverage'])
        else:
            historical_ensemble={
                'status':'unavailable','reason':'source_engine_reliability_gate',
                'probability':None,'q_win':None,'q_push':None,
                'historical_families':[],'historical_unavailable':{},
                'historical_family_weights':{},'weight_historical':policy['weight_a'],
                'weight_b':policy['weight_b'],'publication_eligible':False,
                'empirically_calibrated':False}
        models['Consensus']={
            'probability':historical_ensemble['probability'],
            'q_win':historical_ensemble['q_win'],
            'q_push':historical_ensemble['q_push'],
            'status':historical_ensemble['status'],
            'reason':historical_ensemble.get('reason'),
            'version':policy['version'],
            'historical_families':historical_ensemble['historical_families'],
            'historical_family_weights':historical_ensemble['historical_family_weights'],
            'empirically_calibrated':False,
            'finalized_post_shadow':True}
    # Explicit side-by-side research-only probability. NEVER used as a
    # fallback for the strict NUTS column or the production consensus.
    research=indices.get('NUTS_provisional',{}).get(key)
    provisional=linked_probability(row,research) if research else {
        'probability':None,'status':'unavailable',
        'reason':'no_eligible_provisional_nuts_artifact_for_exact_contract'}
    models['NUTS_provisional']=provisional
    record={k:row.get(k) for k in ('game_date','run_id','forecast_at','event_start','sport','player','player_id','team','opponent','stat','side')}
    record.update(line=row.get('reference_line'),reference_line=row.get('reference_line'),original_rank=row.get('final_rank'),block_reason=row.get('reason'),
                  probability_scale='P(exact_side_wins | no_push)',models=models,nuts_models=nuts,
                  NUTS_model=selected,NUTS_status=chosen['status'],NUTS_reason=chosen.get('reason'),
                  production_consensus_available=models['Consensus']['probability'] is not None,
                  provisional_nuts_status=provisional['status'],
                  provisional_nuts_reason=provisional.get('reason'),
                  production_policy_version=(policy['version'] if historical_ensemble is not None else blend.get('version')),
                  production_ensemble=historical_ensemble,
                  source_snapshot_preliminary=bool(blend.get('preliminary')),
                  context_adjustment_applied=(row.get('shared_context') or {}).get('applied',False))
    for name,value in models.items():record[name]=value['probability']
    record['Consensus_gap_pp']=100*(record['Consensus']-record['Market']) if record['Consensus'] is not None and record['Market'] is not None else None
    return record



def enforce_paired_probability_integrity(records, *, tolerance=1e-8):
    """Fail closed on incompatible Over/Under forecasts for one exact contract.

    NUTS population simulations are matched at player/game/line rather than
    per-side forecast timestamp. The original November 8 archive demonstrated
    independent stochastic draws on rows a few milliseconds apart. Never
    rescale or silently 'repair' a frozen forecast by renormalization.
    """
    groups={}
    for record in records:
        line=record.get('reference_line',record.get('line'))
        if type(line) not in (int,float) or not math.isfinite(line):
            raise ValueError('invalid_paired_probability_line')
        key=tuple(str(record.get(k) or '') for k in (
            'run_id','game_date','sport','event_start','team','opponent',
            'player_id','player','stat'))+(format(float(line),'.15g'),)
        side=record.get('side')
        if side not in ('over','under'):
            raise ValueError('invalid_paired_probability_side')
        group=groups.setdefault(key,{})
        if side in group:
            raise ValueError('duplicate_paired_probability_side')
        group[side]=record
    rejected=0
    for group in groups.values():
        if set(group)!= {'over','under'}:
            continue
        over,under=group['over'],group['under']
        issues=[]
        for name in ('NUTS','Consensus'):
            a,b=over.get(name),under.get(name)
            if a is None or b is None:
                continue
            if (type(a) not in (int,float) or type(b) not in (int,float)
                    or not math.isfinite(a) or not math.isfinite(b)
                    or abs(a+b-1.)>tolerance):
                issues.append((name,a,b))
        if not issues:
            continue
        rejected+=1
        # Preserve exact original component values in a separate audit field
        # before withholding the potentially invalid published probabilities.
        issue_labels=[name+'_over_under_not_complementary' for name,_,_ in issues]
        reason=';'.join(issue_labels)
        for record in (over,under):
            record['paired_probability_integrity']={
                'status':'rejected','reason':reason,
                'raw_probability_pairs':{name:{'over':a,'under':b,
                         'sum':a+b if type(a) in (int,float) and type(b) in (int,float) else None}
                    for name,a,b in issues}}
            consensus=(record.get('models') or {}).get('Consensus')
            if consensus is not None:
                consensus.update(probability=None,status='unavailable',
                                 reason='noncomplementary_paired_forecast')
            record.update(Consensus=None,Consensus_gap_pp=None,
                          production_consensus_available=False,
                          block_reason='NONCOMPLEMENTARY_PAIRED_FORECAST')
            ensemble=record.get('production_ensemble')
            if isinstance(ensemble,dict):
                ensemble.update(status='unavailable',
                                reason='noncomplementary_paired_forecast',
                                probability=None,q_win=None,q_push=None,q_loss=None,
                                publication_eligible=False)
            if any(name=='NUTS' for name,_,_ in issues):
                nuts=(record.get('models') or {}).get('NUTS')
                if nuts is not None:
                    nuts.update(probability=None,status='unavailable',
                                reason='noncomplementary_nuts_paired_forecast')
                record.update(NUTS=None,NUTS_status='unavailable',
                              NUTS_reason='noncomplementary_nuts_paired_forecast')
    return {'checked_contracts':sum(set(g)=={'over','under'} for g in groups.values()),
            'rejected_contracts':rejected,'tolerance':tolerance}


def run(root,day,out_dir):
    import live_pool_exchange as pool
    root=Path(root);out_dir=Path(out_dir);out_dir.mkdir(parents=True,exist_ok=True)
    snapshots,run_id=pool.pick_latest(rows(root/'data/prop_snapshots.jsonl'),day)
    indices={}
    for name,folder in FOLDERS.items():
        items=rows(root/'data'/folder/(day+'.jsonl'))
        if name=='NUTS_targets':
            # The targets adapter stores its source timestamp separately.
            items=[{**r,'forecast_at':r.get('parent_forecast_at',r.get('forecast_at')),
                    'generated_at':r.get('generated_at') or r.get('forecast_at')} for r in items if r.get('line_origin')=='market']
        if name in ('NUTS_population','NUTS_targets','NUTS_provisional'):
            # Failed retries are audit records, not conflicting forecasts. Keep
            # the earliest successful inference; conflicting probabilities fail.
            grouped={}
            for item in sorted(items,key=lambda x:str(x.get('generated_at') or '')):
                k=identity(item);previous=grouped.get(k)
                if previous and previous.get('status')=='forecast':
                    if item.get('status')=='forecast' and any(
                            previous.get(f)!=item.get(f) for f in ('q_win','q_push','q_over','q_under')):
                        raise ValueError('conflicting_model_sidecar_identity')
                    continue
                if previous is None or item.get('status')=='forecast':grouped[k]=item
            items=list(grouped.values())
        indices[name]=index_sidecars(items)
    quotes=rows(root/'data/odds_quotes.jsonl')
    policy=production_policy(root)
    records=[build(r,indices,quotes,policy=policy) for r in snapshots]
    pair_integrity=enforce_paired_probability_integrity(records)
    inputs={'snapshots_sha256':hashlib.sha256((root/'data/prop_snapshots.jsonl').read_bytes()).hexdigest(),
            'code_sha':os.environ.get('PICKEM_CODE_SHA'),
            'comparison_schema':VERSION,'day':day,'run_id':run_id,'rows':len(records),
            'production':policy['model'] if policy else 'legacy_unconfigured',
            'production_policy_version':policy['version'] if policy else None,
            'forecast_weights':(
                {'historical_ensemble':policy['weight_a'],'engine_b':policy['weight_b'],
                 'historical_models':policy['historical_models']}
                if policy and policy.get('model')=='historical_consensus_engine_b'
                else {'a':policy['weight_a'],'b':policy['weight_b']}
                if policy else None),
            'probability_scale':'conditional_on_nonpush','training_started':False,
            'paired_probability_integrity':pair_integrity}
    payload={'schema':VERSION,'metadata':inputs,'picks':records}
    paths={'json':out_dir/'slate_model_comparisons.json','csv':out_dir/'slate_model_comparisons.csv',
           'markdown':out_dir/'slate_model_comparisons.md'}
    paths['json'].write_text(json.dumps(payload,indent=2,sort_keys=True,allow_nan=False))
    with paths['csv'].open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=COLUMNS,extrasaction='ignore');writer.writeheader();writer.writerows(records)
    lines=['# Slate probability comparison — '+day,'',
           'All probabilities use the same player, side and line and are conditional on no push. N/A means unavailable; it is never a substituted forecast.',
           '', '| Player | Market | Side / line | A | B | Consensus | Bayes A | Bayes B | Market | NUTS | Gap pp |',
           '|---|---|---|---:|---:|---:|---:|---:|---:|---:|---:|']
    def pct(x):return 'N/A' if x is None else f'{100*x:.1f}%'
    for r in records:
        vals=[pct(r.get(k)) for k in ('Engine_A','Engine_B','Consensus','Bayesian_A','Bayesian_B','Market','NUTS')]
        lines.append('| '+str(r['player']).replace('|','/')+' | '+str(r['stat'])+' | '+str(r['side'])+' '+str(r['line'])+' | '+' | '.join(vals)+' | '+('N/A' if r['Consensus_gap_pp'] is None else f"{r['Consensus_gap_pp']:+.1f}")+' |')
    paths['markdown'].write_text('\n'.join(lines)+'\n')
    # Produce evidence-backed top ten per sport from the SAME immutable comparison
    # and complete original batch, independent of the capped triage queue.
    from slate_candidate_ranking import build as rank_candidates, write as write_candidates
    ranked = rank_candidates(snapshots, records, day, data_root=root/'data')
    write_candidates(ranked, out_dir)
    # Archive every displayed model probability alongside its source forecast.
    # Same-run retries preserve earlier reports rather than rewriting history.
    sidecar=root/'data/model_comparisons'/(day+'.jsonl')
    prior=rows(sidecar);seen={identity(r) for r in prior}
    pool.dump_jsonl(sidecar,prior+[r for r in records if identity(r) not in seen])
    return payload


def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--date',required=True)
    p.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[1]);p.add_argument('--out-dir',type=Path,required=True)
    a=p.parse_args();r=run(a.root,a.date,a.out_dir);print(json.dumps(r['metadata'],sort_keys=True))


if __name__=='__main__':main()
